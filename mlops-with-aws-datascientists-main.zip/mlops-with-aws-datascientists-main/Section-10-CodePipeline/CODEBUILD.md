# Some System Settings to consider
## For CodeBuild Environment, Use the settings as below
OS - Amazon Linux 2
Runtime - Standard
Image - aws/codebuild/amazonlinux2-aarch64-standard:2.0
