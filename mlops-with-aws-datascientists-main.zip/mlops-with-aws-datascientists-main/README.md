# This is a Repository for MLOps Course with AWS 
A Course by Manifold AI Learning to help the practitioners to Master MLOps tasks with AWS - this is hands-on course!

Course link - 

https://www.manifoldailearning.in/courses/Master-Practical-MLOps-for-Data-Scientists--DevOps-on-AWS-65351f01e4b08600bc438698

Be a part of Workshops conducted Live for free - 
https://www.manifoldailearning.in/courses/Webinar-Learning-Materials--Slides-64df2bc5e4b0267d331f9998


Our other best courses:

MLOps Bootcamp - https://www.manifoldailearning.in/courses/Complete-MLOps-BootCamp-654ddf11e4b004edc19e2649

Python for MLOps DevOps AIOps -

 https://www.manifoldailearning.in/courses/Python-Programming-for-DevOps---MLOps-Engineers-6605b6973e488b5c28072d2e

Created by the Top Instructor of Manifold AI Learning - Nachiketh Murthy (https://www.linkedin.com/in/nachiketh-murthy/)

For support - support@manifoldailearning.in

Thank you for all your support. Happy Learning!!!
